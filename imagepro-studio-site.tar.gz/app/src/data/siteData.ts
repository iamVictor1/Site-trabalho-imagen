import type { PortfolioItem, Service, Testimonial, PricingPlan } from '@/types';

export const services: Service[] = [
  {
    id: 1,
    title: 'Fotografia de Comida',
    description: 'Transforme suas fotos de alimentos em imagens irresistíveis que despertam o apetite dos clientes.',
    icon: 'UtensilsCrossed',
    features: [
      'Correção de cores e saturação',
      'Ajuste de iluminação e sombras',
      'Remoção de imperfeições',
      'Realce de texturas',
      'Background enhancement',
    ],
  },
  {
    id: 2,
    title: 'Moda & Roupas',
    description: 'Realce cada detalhe das suas peças de roupa com edição profissional para catálogos e e-commerce.',
    icon: 'Shirt',
    features: [
      'Retoque de tecidos',
      'Ajuste de cores fieis',
      'Remoção de vincos',
      'Correção de iluminação',
      'Padronização de fundo',
    ],
  },
  {
    id: 3,
    title: 'Veículos',
    description: 'Destaque o brilho e a elegância dos veículos com edição que valoriza cada curva e reflexo.',
    icon: 'Car',
    features: [
      'Realce do brilho da pintura',
      'Correção de reflexos',
      'Ajuste de contraste',
      'Remoção de distrações',
      'Color grading profissional',
    ],
  },
  {
    id: 4,
    title: 'Produtos & Perfumes',
    description: 'Crie imagens de produtos que transmitem luxo e qualidade, perfeitas para divulgação premium.',
    icon: 'Sparkles',
    features: [
      'Iluminação perfeita',
      'Reflexos realistas',
      'Correção cromática',
      'Detalhes nítidos',
      'Atmosfera de luxo',
    ],
  },
];

export const portfolioItems: PortfolioItem[] = [
  {
    id: 1,
    title: 'Hambúrguer Gourmet',
    category: 'food',
    image: '/images/portfolio/food/food-1.jpg',
    description: 'Edição que realçou as cores vibrantes e a textura suculenta do hambúrguer.',
  },
  {
    id: 2,
    title: 'Torta de Chocolate',
    category: 'food',
    image: '/images/portfolio/food/food-2.jpg',
    description: 'Tratamento de imagem para destacar o brilho do chocolate e a frescura dos morangos.',
  },
  {
    id: 3,
    title: 'Vestido de Festa',
    category: 'fashion',
    image: '/images/portfolio/fashion/fashion-1.jpg',
    description: 'Edição que valorizou o brilho do tecido e a elegância da peça.',
  },
  {
    id: 4,
    title: 'Terno Executivo',
    category: 'fashion',
    image: '/images/portfolio/fashion/fashion-2.jpg',
    description: 'Ajuste de cores e iluminação para um look profissional impecável.',
  },
  {
    id: 5,
    title: 'Esportivo Vermelho',
    category: 'automotive',
    image: '/images/portfolio/automotive/car-1.jpg',
    description: 'Realce do brilho da pintura e dos reflexos para um visual impactante.',
  },
  {
    id: 6,
    title: 'SUV de Luxo',
    category: 'automotive',
    image: '/images/portfolio/automotive/car-2.jpg',
    description: 'Color grading que destacou a elegância e sofisticação do veículo.',
  },
  {
    id: 7,
    title: 'Perfume Masculino',
    category: 'perfumes',
    image: '/images/portfolio/perfumes/perfume-1.jpg',
    description: 'Iluminação dramática que criou uma atmosfera de luxo e exclusividade.',
  },
  {
    id: 8,
    title: 'Perfume Feminino',
    category: 'perfumes',
    image: '/images/portfolio/perfumes/perfume-2.jpg',
    description: 'Edição suave que transmitiu delicadeza e sofisticação.',
  },
];

export const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Ana Silva',
    company: 'Restaurante Sabor & Arte',
    text: 'As fotos do nosso cardápio ficaram incríveis! As imagens editadas aumentaram nossas vendas online em 40%.',
    avatar: 'AS',
    rating: 5,
  },
  {
    id: 2,
    name: 'Carlos Mendes',
    company: 'Concessionária Premium Motors',
    text: 'Profissionalismo impecável. Os carros nunca pareceram tão bem nas fotos. Recomendo fortemente!',
    avatar: 'CM',
    rating: 5,
  },
  {
    id: 3,
    name: 'Juliana Costa',
    company: 'Boutique Elegance',
    text: 'Nosso e-commerce ganhou vida nova com as imagens editadas. A qualidade é excepcional!',
    avatar: 'JC',
    rating: 5,
  },
  {
    id: 4,
    name: 'Roberto Almeida',
    company: 'Perfumaria Lux',
    text: 'O trabalho de edição transmitiu exatamente a sofisticação que nossa marca precisava.',
    avatar: 'RA',
    rating: 5,
  },
];

export const pricingPlans: PricingPlan[] = [
  {
    id: 1,
    name: 'Pacote Start',
    price: 'R$ 49,90',
    description: '5 imagens',
    features: [
      'Edição profissional',
      'Correção de cores',
      'Ajuste de iluminação',
      'Entrega em 48h',
      '2 revisões inclusas',
    ],
  },
  {
    id: 2,
    name: 'Pacote Pro',
    price: 'R$ 89,90',
    description: '10 imagens',
    features: [
      'Edição profissional',
      'Retoque avançado',
      'Correção de cores',
      'Ajuste de iluminação',
      'Entrega em 48h',
      'Revisões ilimitadas',
    ],
    highlighted: true,
  },
  {
    id: 3,
    name: 'Pacote Business',
    price: 'R$ 159,90',
    description: '30 imagens',
    features: [
      'Edição profissional',
      'Retoque avançado',
      'Correção de cores',
      'Ajuste de iluminação',
      'Entrega em 72h',
      'Revisões ilimitadas',
      'Prioridade na fila',
    ],
  },
];

// WhatsApp number for orders
export const WHATSAPP_NUMBER = '5569999370716';

// Function to generate WhatsApp link with message
export const generateWhatsAppLink = (planName: string, price: string, images: string): string => {
  const message = `Olá! Tenho interesse no ${planName} de ${price} (${images}). Gostaria de saber mais informações e fazer o pedido!`;
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
};

export const stats = [
  { value: '500+', label: 'Imagens Editadas' },
  { value: '100+', label: 'Clientes Satisfeitos' },
  { value: '4.9', label: 'Avaliação Média' },
  { value: '3', label: 'Anos de Experiência' },
];
