export interface PortfolioItem {
  id: number;
  title: string;
  category: 'food' | 'fashion' | 'automotive' | 'perfumes';
  image: string;
  beforeImage?: string;
  description: string;
}

export interface Service {
  id: number;
  title: string;
  description: string;
  icon: string;
  features: string[];
}

export interface Testimonial {
  id: number;
  name: string;
  company: string;
  text: string;
  avatar: string;
  rating: number;
}

export interface PricingPlan {
  id: number;
  name: string;
  price: string;
  description: string;
  features: string[];
  highlighted?: boolean;
}
