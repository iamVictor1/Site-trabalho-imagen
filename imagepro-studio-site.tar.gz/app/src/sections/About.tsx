import { Camera, Palette, Zap, Send, CheckCircle } from 'lucide-react';

const processSteps = [
  {
    icon: Send,
    title: 'Envio',
    description: 'Você envia as imagens originais que precisam ser editadas.',
  },
  {
    icon: Palette,
    title: 'Edição',
    description: 'Realizo a edição profissional com base nas suas necessidades.',
  },
  {
    icon: CheckCircle,
    title: 'Revisão',
    description: 'Você revisa e solicita ajustes se necessário.',
  },
  {
    icon: Zap,
    title: 'Entrega',
    description: 'Receba as imagens finais em alta resolução.',
  },
];

const diferenciais = [
  {
    icon: Camera,
    title: 'Qualidade Profissional',
    description: 'Uso técnicas avançadas de edição para garantir resultados de alta qualidade.',
  },
  {
    icon: Zap,
    title: 'Entrega Rápida',
    description: 'Prazos curtos sem comprometer a qualidade do trabalho.',
  },
  {
    icon: Palette,
    title: 'Personalização',
    description: 'Cada projeto é tratado de forma única, de acordo com suas necessidades.',
  },
];

export default function About() {
  return (
    <section id="about" className="py-20 lg:py-32 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-4">
            Sobre Mim
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Quem está por trás das{' '}
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              imagens perfeitas
            </span>
          </h2>
        </div>

        {/* About Content */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-20">
          {/* Left - Image */}
          <div className="relative">
            <div className="aspect-[4/5] rounded-2xl overflow-hidden">
              <img
                src="/images/portfolio/automotive/car-1.jpg"
                alt="Workspace"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-6 bg-white rounded-xl p-6 shadow-xl">
              <div className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                3+
              </div>
              <div className="text-gray-600">Anos de Experiência</div>
            </div>
          </div>

          {/* Right - Content */}
          <div className="space-y-6">
            <p className="text-lg text-gray-600">
              Sou um editor de imagens profissional especializado em transformar
              fotos comuns em imagens extraordinárias. Com mais de 3 anos de
              experiência, já ajudei mais de 100 empresas a elevarem a qualidade
              visual de seus produtos.
            </p>
            <p className="text-lg text-gray-600">
              Meu trabalho envolve desde a correção básica de cores até edições
              complexas que destacam os melhores aspectos de cada imagem. Seja
              para restaurantes, lojas de moda, concessionárias ou perfumarias,
              garanto resultados que impressionam.
            </p>

            {/* Diferenciais */}
            <div className="grid sm:grid-cols-3 gap-6 pt-6">
              {diferenciais.map((item) => (
                <div key={item.title} className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                    <item.icon className="w-6 h-6 text-purple-600" />
                  </div>
                  <h4 className="font-bold text-gray-900 mb-1">{item.title}</h4>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Process Steps */}
        <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-sm">
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-10">
            Como Funciona
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <div key={step.title} className="relative">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-100 to-blue-100 rounded-2xl flex items-center justify-center mb-4">
                    <step.icon className="w-8 h-8 text-purple-600" />
                  </div>
                  <div className="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center text-sm font-bold mb-3">
                    {index + 1}
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">{step.title}</h4>
                  <p className="text-sm text-gray-600">{step.description}</p>
                </div>
                {index < processSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-purple-200 to-transparent" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
