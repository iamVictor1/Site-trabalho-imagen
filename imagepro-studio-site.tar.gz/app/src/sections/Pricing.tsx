import { Check, ArrowRight, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { pricingPlans, generateWhatsAppLink } from '@/data/siteData';

export default function Pricing() {
  const handleWhatsAppClick = (planName: string, price: string, description: string) => {
    const whatsappUrl = generateWhatsAppLink(planName, price, description);
    window.open(whatsappUrl, '_blank');
  };

  return (
    <section id="pricing" className="py-20 lg:py-32 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 bg-green-100 text-green-700 rounded-full text-sm font-medium mb-4">
            Pacotes
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Escolha seu{' '}
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Pacote
            </span>
          </h2>
          <p className="text-lg text-gray-600">
            Pacotes com valores especiais para você economizar. Clique em comprar e
            converse diretamente comigo pelo WhatsApp.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 max-w-5xl mx-auto">
          {pricingPlans.map((plan) => (
            <div
              key={plan.id}
              className={`relative rounded-2xl p-6 lg:p-8 ${
                plan.highlighted
                  ? 'bg-gradient-to-br from-purple-600 to-blue-600 text-white shadow-xl scale-105'
                  : 'bg-white text-gray-900 shadow-sm'
              }`}
            >
              {/* Popular Badge */}
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="bg-yellow-400 text-yellow-900 px-4 py-1 rounded-full text-sm font-bold">
                    Mais Popular
                  </span>
                </div>
              )}

              {/* Plan Header */}
              <div className="text-center mb-6">
                <h3
                  className={`text-xl font-bold mb-2 ${
                    plan.highlighted ? 'text-white' : 'text-gray-900'
                  }`}
                >
                  {plan.name}
                </h3>
                <div className="flex items-baseline justify-center gap-1">
                  <span
                    className={`text-4xl font-bold ${
                      plan.highlighted ? 'text-white' : 'text-gray-900'
                    }`}
                  >
                    {plan.price}
                  </span>
                </div>
                <span
                  className={`text-sm font-medium ${
                    plan.highlighted ? 'text-white/90' : 'text-purple-600'
                  }`}
                >
                  {plan.description}
                </span>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center ${
                        plan.highlighted
                          ? 'bg-white/20'
                          : 'bg-green-100'
                      }`}
                    >
                      <Check
                        className={`w-3 h-3 ${
                          plan.highlighted ? 'text-white' : 'text-green-600'
                        }`}
                      />
                    </div>
                    <span
                      className={`text-sm ${
                        plan.highlighted ? 'text-white/90' : 'text-gray-600'
                      }`}
                    >
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA Button - WhatsApp */}
              <Button
                onClick={() => handleWhatsAppClick(plan.name, plan.price, plan.description)}
                className={`w-full ${
                  plan.highlighted
                    ? 'bg-white text-purple-600 hover:bg-gray-100'
                    : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700'
                }`}
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Comprar pelo WhatsApp
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          ))}
        </div>

        {/* WhatsApp Direct CTA */}
        <div className="mt-12 text-center">
          <a
            href={`https://wa.me/5569999370716?text=${encodeURIComponent('Olá! Gostaria de saber mais informações sobre os pacotes de edição de imagens.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-gray-600 hover:text-purple-600 transition-colors"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Prefere negociar um pacote personalizado? Me chame no WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
}
