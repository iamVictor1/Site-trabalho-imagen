import { ArrowRight, Play, Star, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { stats } from '@/data/siteData';

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="/images/hero/hero-banner.jpg"
          alt="Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900/95 via-gray-900/80 to-gray-900/60" />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 pt-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full border border-white/20">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-sm text-white/90">
                Mais de 500 imagens transformadas
              </span>
            </div>

            {/* Headline */}
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
                Transforme suas{' '}
                <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                  imagens
                </span>{' '}
                em obras de arte
              </h1>
              <p className="text-lg sm:text-xl text-white/80 max-w-xl">
                Especialista em edição profissional de imagens para comida,
                roupas, veículos e perfumes. Eleve a qualidade visual da sua
                marca.
              </p>
            </div>

            {/* Features */}
            <div className="flex flex-wrap gap-4">
              {['Entrega Rápida', 'Alta Qualidade', 'Preços Justos'].map(
                (feature) => (
                  <div
                    key={feature}
                    className="flex items-center gap-2 text-white/80"
                  >
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <span className="text-sm">{feature}</span>
                  </div>
                )
              )}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8"
              >
                Solicitar Orçamento
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 px-8"
              >
                <Play className="w-5 h-5 mr-2" />
                Ver Portfólio
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-8 border-t border-white/10">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <div className="text-2xl sm:text-3xl font-bold text-white">
                    {stat.value}
                  </div>
                  <div className="text-sm text-white/60">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Content - Preview Cards */}
          <div className="hidden lg:block relative">
            <div className="relative w-full aspect-square">
              {/* Floating Cards */}
              <div className="absolute top-0 right-0 w-48 h-64 rounded-2xl overflow-hidden shadow-2xl transform rotate-6 animate-float">
                <img
                  src="/images/portfolio/food/food-1.jpg"
                  alt="Food"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute top-20 left-0 w-48 h-64 rounded-2xl overflow-hidden shadow-2xl transform -rotate-3 animate-float-delayed">
                <img
                  src="/images/portfolio/fashion/fashion-1.jpg"
                  alt="Fashion"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute bottom-0 right-10 w-48 h-64 rounded-2xl overflow-hidden shadow-2xl transform rotate-3 animate-float">
                <img
                  src="/images/portfolio/perfumes/perfume-1.jpg"
                  alt="Perfume"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1.5 h-3 bg-white/60 rounded-full mt-2 animate-bounce" />
        </div>
      </div>
    </section>
  );
}
